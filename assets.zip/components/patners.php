<div class="container-fluid pt-5 pb-5">
    <div class="row">
        <div class="col-md-10 offset-md-1 text-center">
            <h3>Our Patners</h3>
            <hr>
            <br>
            <a href="https://developers.google.com/groups/"><img src="assets/img/patners/GDG-program-logo.png" width="140vh"></a>
            <a href="https://www.womentechmakers.com/"><img src="assets/img/patners/WT_logo_horizontal_pos.png" width="280vh"></a>
            <img src="assets/img/patners/gsa.jpg" width="140vh">&nbsp;
             <br>
             <br>
             <a href="mailto:gdgjalandhar@gmail.com" class="btn btn-primary btn-md m-0 waves-effect waves-light" role="button">Become a Sponsor</a>
        </div>
    </div>
</div>