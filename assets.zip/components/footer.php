<div class="container-fluid pt-5 pb-2 grey lighten-5" style="z-index:2000">
    <div class="row">
        <div class="col-md-10 offset-md-1">
            <h3 class="google-font" style="color:#424242 "><b>Google IO18 Extended</b></h3>
            <p>Designed & Developed By GDG Jalandhar</p>
        </div>
    </div>
</div>