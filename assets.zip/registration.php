<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags always come first -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no, user-scalable=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>IO18 Extended</title>
    <?php include "components/headerScript.php" ?>

</head>

<body class="white-skin">
    <?php include "components/navbar.php" ?>
    <br><br>
    <div class="container-fluid mt-1 pt-5 pb-5"  style="border-top: 4.8px solid #9e9e9e;" >
        <div class="row align-items-center">
            <div class="col-md-10 offset-md-1 p-3" >
                <h1 class="google-font h1-responsive" style="color: #616161 ">Registration is Open</h1>
                <p>You will automatically be placed on the waitlist while we process your application, and if a spot becomes available, we will let you know via email. If you can't make it, be sure to watch the livestream.
                <br><br>Questions? Please contact gdgjalandhar@gmail.com. 
                <a href="#">GDG Jalandhar Code of Conduct</a></p> 
                <br>  
                <hr>
            </div>
        </div>

        <div class="row align-items-center mt-4">
            <div class="col-md-8 offset-md-2 pt-2 pb-2" >
                <div class="container-fluid">

                    <div class="row mb-5 pb-5">
                        <!-- <div class="col-md-2 text-center">
                            <p style="background: #31E7B6;height: 40px;width: 40px;" class="p-2"><b>1</b></p> 
                        </div> -->
                        <div class="col-md-10">
                            <h4 id="SignInHeader"><span style="background: #31E7B6;height: 40px;width: 40px;" class="p-2"><b> &nbsp; 1 &nbsp; </b></span> &nbsp; Sign in</h4>
                            <br>
                            <p id="SignInMsg" style="font-size: 130%;color: #616161" class="google-font">You need to sign in with a Google account or a Gmail address to register for this event.</p>

                            <button type="button" id="login" class="btn btn-primary m-0 z-depth-0">Sign in with Google</button>
                            <button type="button" id="logout" class="btn btn-danger m-0 z-depth-0 btn-sm">Logout</button>
                        </div>
                    </div>

                    <!-- Row 2 Details -->
                    <div class="row mt-5 pb-5" id="UserDetails">
                        <!-- <div class="col-md-2 text-center">
                            <p style="background: #31E7B6;height: 40px;width: 40px;" class="p-2"><b>2</b></p> 
                        </div> -->
                        <div class="col-md-10">
                            <h4><span style="background: #31E7B6;height: 40px;width: 40px;" class="p-2"><b> &nbsp; 2 &nbsp; </b></span> &nbsp; Your details</h4>
                            <br>
                            <p style="font-size: 130%;color: #616161" class="google-font"><b>We're accepting registrations from this form on a first-come, first-served basis until seats are full. </b></p>

                            <div class="container-fluid p-0" id="UserInput">
                                    <div class="row">
                                        <div class="col-md-8">
                                            <br>
                                            <div class="md-form">
                                                <input type="text" id="name" class="form-control">
                                                <label for="name">Full Name</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-8">
                                            <br>
                                            <div class="md-form">
                                                <input type="number" id="mobile" class="form-control">
                                                <label for="mobile">Contact Number</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-8">
                                            <br>
                                            <div class="md-form">
                                                <input type="text" id="organization" class="form-control">
                                                <label for="organization">Organization/University</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-8">
                                            <br>
                                            <div class="md-form">
                                                <input type="text" id="designation" class="form-control">
                                                <label for="designation">Stream/Semester/Designation(For Employee)</label>
                                                <small style="color:#CC0000" class="mt-0">In Case of Organization Write Your Designation</small>
                                            </div>
                                        </div>
                                    </div>
                                    <br>
                                    <div class="row">
                                        <div class="col-md-8">
                                            <br>
                                            <div class="md-form">
                                                <textarea type="text" id="why" class="md-textarea md-textarea-auto form-control" rows="2"></textarea>
                                                <label for="why">Why do you want to attend Google IO Extended'18?</label>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-8">
                                            <br>
                                            <button type="button" class="m-0 btn btn-primary waves-effect waves-light z-depth-0" id="submit">SUBMIT</button>
                                        </div>
                                    </div>
                                    
                                </div>
                        </div>
                    </div>
                    <!-- Row 2 Details End -->

                    <!-- Row 3 Success -->
                    <div class="row mt-5" id="confirmation">
                            <div class="col-md-10">
                                <h4><span style="background: #31E7B6;height: 40px;width: 40px;" class="p-2"><b> &nbsp; 3 &nbsp; </b></span> &nbsp; Confirmation</h4>
                                <br>
                                <p style="font-size: 130%;color: #616161" class="google-font"><b>Your Details has been submitted Successfully! </b></p>
    
                            </div>
                        </div>
                    <!-- Row 3 Success -->

                    <!--  -->
                    <!-- Row 3 Success -->
                    <div class="row mt-5" id="updateData">
                        <div class="col-md-10">
                            <h4> <span style="background: #31E7B6;height: 40px;width: 40px;" class="p-2"><b> &nbsp; 2 &nbsp; </b></span> &nbsp; Confirmation</h4>
                            <br>
                            <p style="font-size: 130%;color: #616161" class="google-font"><b>You have already filled this form.If you want to update this form then mail at vrijraj2396@gmail.com </b></p>

                        </div>
                    </div>
                    <!-- Row 3 Success -->


                </div>
            </div>
        </div>
    </div>

   
    
    <?php include "components/patners.php" ?>
    <?php include "components/socials.php" ?>


    <?php include "components/footer.php" ?>
    <?php include "components/footerScript.php" ?>


    <script src="https://www.gstatic.com/firebasejs/4.13.0/firebase.js"></script>
    <script>
        //Hide the Content
        document.getElementById('UserDetails').style.display="none";
        document.getElementById('confirmation').style.display="none";
        document.getElementById('logout').style.display="none";
        document.getElementById('updateData').style.display="none";

        // Initialize Firebase
        var config = {
            apiKey: "AIzaSyBRibNRUINQaIrz2eyk0H2NyDNQDE0ozcM",
            authDomain: "io2018web.firebaseapp.com",
            databaseURL: "https://io2018web.firebaseio.com",
            projectId: "io2018web",
            storageBucket: "io2018web.appspot.com",
            messagingSenderId: "215081620072"
        };
        firebase.initializeApp(config);

        //Call Events
        document.getElementById('login').addEventListener('click',loginUser);
        document.getElementById('submit').addEventListener('click',addData);
        document.getElementById('logout').addEventListener('click',logoutUser);


        //Google Sign In Provider
        var provider = new firebase.auth.GoogleAuthProvider();
        
        //Call Functions
        function loginUser(){
            firebase.auth().signInWithPopup(provider).then(function(result) {
                  var token = result.credential.accessToken;
                  var user = result.user;
                  console.log(user);     
            }).catch(function(error) {
              var errorCode = error.code;
              var errorMessage = error.message;
              var email = error.email;
              var credential = error.credential;
            });
        }

        function logoutUser(){
            firebase.auth().signOut().then(function() {
                // Sign-out successful.
                document.getElementById('logout').style.display="none";
                document.getElementById('login').style.display="block";
                document.getElementById('UserDetails').style.display="none";
                document.getElementById('updateData').style.display="none";
            }).catch(function(error) {
            // An error happened.
            });
        }


        var email;
        var uid;
        console.log("User Email "+email);
        
        function addData(){
            if(email){
                var name=document.getElementById('name').value;
                var mobile=document.getElementById('mobile').value;
                var organization=document.getElementById('organization').value;
                var designation=document.getElementById('designation').value;
                var why=document.getElementById('why').value;
                
                var data={
                    name:name,
                    email:email,
                    mobile:mobile,
                    org:organization,
                    designation:designation,
                    why:why,
                    timestamp:Date(),
                    uid:uid
                }
                
                firebase.database().ref('IOAttendees/'+uid).set(data).then(()=>{
                    alert("User SuccessFully Registered");
                    document.getElementById('UserInput').innerHTML="Thank you Filling this Form";
                    document.getElementById('confirmation').style.display="block";


                })
                console.log(email);
            }
            else{
                alert("you need to Login with Google");
                //document.getElementById('userDetailSection').innerHTML="Thank you Filling this Form";
            }
          
        }


         firebase.auth().onAuthStateChanged(function(user) {
            if (user) {
                var displayName = user.displayName;
                email = user.email;
                var emailVerified = user.emailVerified;
                var photoURL = user.photoURL;
                var isAnonymous = user.isAnonymous;
                uid = user.uid;
                var providerData = user.providerData;
                
                console.log(email);

                document.getElementById('SignInMsg').innerHTML="<b style='color:blue'>"+displayName+"</b> Successfully Logged In with : <b style='color:blue'>"+email+"</b>";

                document.getElementById('logout').style.display="block";
                document.getElementById('login').style.display="none";
                
                
                
                firebase.database().ref('IOAttendees/'+uid).once('value',(snap)=>{
                    if(snap.val()){
                        document.getElementById('UserDetails').style.display="none";
                        document.getElementById('updateData').style.display="block";
                    }
                    else{
                        document.getElementById('UserDetails').style.display="block";
                    }
                })
                // ...
            } else {
                // User is signed out.
                // ...
                document.getElementById('UserDetails').style.display="none";
                console.log("err");
                document.getElementById('SignInMsg').innerHTML="You need to sign in with a Google account or a Gmail address to register for this event.";
            }
        });



        

    </script>

</body>
</html>