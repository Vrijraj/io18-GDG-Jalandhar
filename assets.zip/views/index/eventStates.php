<div class="container-fluid mt-5 primary-color-dark ">
        <div class="row ">
            <div class="col-md-10 primary-color-dark pt-3 pb-3 offset-md-1 text-white">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12 pt-5 pb-5">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-3 col-3 text-center">
                                        <h1 class="h1-responsive">130</h1>
                                        <p>Attendees</p>
                                    </div>
                                    <div class="col-md-3 col-3 text-center">
                                        <h1 class="h1-responsive">1</h1>
                                        <p>Day</p>
                                    </div>
                                    <div class="col-md-3 col-3 text-center  ">
                                        <h1 class="h1-responsive">8</h1>
                                        <p>Sessions</p>
                                    </div>
                                    <div class="col-md-3 col-3 text-center">
                                        <h1 class="h1-responsive">7</h1>
                                        <p>Speakers</p>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <p>Google IO18 Extended brings together the world class experts in Android, Web and Cloud technologies to Punjab for a day of sessions, workshops and showcases.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>