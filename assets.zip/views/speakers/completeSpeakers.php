<div class="container-fluid">
     <div class="row">
         <div class="col-md-10 offset-md-1 ">
             <section class="magazine-section">
                <div class="container mt-5">
                    <!-- Row 1 -->
                    <div class="row">
                        <div class="col-md-3 text-center mb-4">
                            <img src="assets/img/speakers/avatar.png" class="img-fluid rounded-circle" width="60%">
                            <br><br>
                            <h5>Name</h5>
                            <p>Position and Comapany</p>
                        </div>

                        <div class="col-md-3 text-center mb-4">
                            <img src="assets/img/speakers/avatar.png" class="img-fluid rounded-circle" width="60%">
                            <br><br>
                            <h5>Name</h5>
                            <p>Position and Comapany</p>
                        </div>

                        <div class="col-md-3 text-center mb-4">
                            <img src="assets/img/speakers/avatar.png" class="img-fluid rounded-circle" width="60%">
                            <br><br>
                            <h5>Name</h5>
                            <p>Position and Comapany</p>
                        </div>
                        
                        <div class="col-md-3 text-center mb-4">
                            <img src="assets/img/speakers/avatar.png" class="img-fluid rounded-circle" width="60%">
                            <br><br>
                            <h5>Name</h5>
                            <p>Position and Comapany</p>
                        </div>

                    </div>
                    <!-- Row 1 End -->


                    <!-- Row 2 -->
                    <div class="row mt-5">
                        <div class="col-md-3 text-center mb-4">
                            <img src="assets/img/speakers/avatar.png" class="img-fluid rounded-circle" width="60%">
                            <br><br>
                            <h5>Name</h5>
                            <p>Position and Comapany</p>
                        </div>

                        <div class="col-md-3 text-center mb-4">
                            <img src="assets/img/speakers/avatar.png" class="img-fluid rounded-circle" width="60%">
                            <br><br>
                            <h5>Name</h5>
                            <p>Position and Comapany</p>
                        </div>

                        <div class="col-md-3 text-center mb-4">
                            <img src="assets/img/speakers/avatar.png" class="img-fluid rounded-circle" width="60%">
                            <br><br>
                            <h5>Name</h5>
                            <p>Position and Comapany</p>
                        </div>
                        
                        <div class="col-md-3 text-center mb-4">
                            <img src="assets/img/speakers/avatar.png" class="img-fluid rounded-circle" width="60%">
                            <br><br>
                            <h5>Name</h5>
                            <p>Position and Comapany</p>
                        </div>

                    </div>
                    <!-- Row 2 End -->
                    
                </div>
            </section>
          </div>
     </div>
 </div>