console.log("Designed and Developed By Vrijraj Singh http://vrijraj.xyz ");
console.log("If you want to contribute in the Website. Kindly mail us at vrijraj2396@gmail.com");